const express = require("express");//import express so we can use express features
const app = express(); //create an instance of express and store it in the variable "app"
const port = 8000;// indicate the port number to run on 
const { faker } = require("@faker-js/faker")

// make sure these lines are above any app.get or app.post code blocks
app.use( express.json() );
app.use( express.urlencoded({ extended: true }) );

class User {
    constructor() {
        this._id = faker.datatype.uuid();
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.internet.email();
        this.password = faker.internet.password();
    }
}

app.get("/api/users/new" , (req,res)=>{
    let fakeUser= new User();

    res.json({ fakeUser })
})

class Company {
    constructor() {
        this._id = faker.datatype.uuid();
        this.name = faker.company.companyName();
        this.streetName= faker.address.streetName();
        this.city = faker.address.city();
        this.state = faker.address.state();
        this.zipCode= faker.address.zipCode();
        this.country= faker.address.country();
    }
}

app.get("/api/companies/new" , (req,res)=> {
    let fakeCompany = new Company(); 
    res.json({ fakeCompany })
})

app.get("/api/user/company" , (req,res)=>{
    let fakeUser = new User();
    let fakeCompany = new Company();
    res.json({ fakeUser, fakeCompany })
})


    /*
   * The output of the above console log will look like this
   * {
   *   name: 'Anime Figure',
   *   price: '$568.00
   *   department: 'Tools' 
   * }
   */



//have this at the bottom of your file. This tells the app to listen for the request on port 8000
app.listen ( port, () => console.log(`Listening on port: ${port}`) );
